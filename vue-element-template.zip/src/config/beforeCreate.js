// 根实例的beforeCreate

export default function(){

}