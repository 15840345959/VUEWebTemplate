<template>
  <div>
  
  </div>
</template>

<script>
import Test from '@c/Test.vue'
export default {

  data (){
    return {
      
    }
  },

}
</script>

<style lang="scss" scoped>

</style>